-CyanE 2024-


_Zip with Legacy Encryption Brute Force_


Requirements to operate Zip Legacy Encryption Brute Force:

-Wordlist
-Zip File encrypted with legacy encryption


How to use?
1. Open the Encrypted Zip File with Zip Brute Force.exe
2. A file dialog will pop up. Find your Wordlist with the file dialog.
3. A terminal will open. Wait until the program stops guessing for passwords 
and a cyan colored text will appear below the terminal that indicates if the 
action is finished.
4. If above the cyan text has a green text, it indicates the success of the 
brute force. The program will automatically extract the files in the folder 
where the zip file is.